package com.mx.java.prueba.uno;

import java.util.Scanner;

public class HipotenusaXXX {

	public static void main(String[] args) {
		
		 Scanner scanner = new Scanner(System.in);
		 double catetoA = 0;
		 double catetoB = 0;
		 System.out.println("Capture el valor del cateto A: ");
		 if (scanner.hasNextDouble()) {
			 catetoA = scanner.nextDouble();
			 System.out.println("Capture el valor del cateto B: ");
			 if (scanner.hasNextDouble()) {
				 catetoB = scanner.nextDouble();
				 System.out.println("El valor de la hipotenusa es: " + Math.hypot(catetoA, catetoB));
			 } else {
				 System.out.println("El valor del cateto B ingresado no es numerico. FIN");
			 }
		 } else {
			 System.out.println("El valor del cateto A ingresado no es numerico. FIN");
		 }
		 scanner.close();
	}
	
}
