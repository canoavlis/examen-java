package com.mx.java.prueba.tres;

public class RestaXXX {

	public static void main(String[] args) {
		double d1 = Double.parseDouble(args[0]);
		double d2 = Double.parseDouble(args[1]);
		double d3 = d1 - d2;
		System.out.println(new RestaXXX().redondeaADecimales(d3, 2));
	}

	public double redondeaADecimales(double valorSinRedondear, int numeroDeDecimales) {
		return Math.round(valorSinRedondear * Math.pow(10, numeroDeDecimales)) / Math.pow(10, numeroDeDecimales);
	}
	
}
