package com.mx.java.prueba.dos;

public class Cliente {

	private String numero;
	
	private CuentaBancaria cuenta;

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public CuentaBancaria getCuenta() {
		return cuenta;
	}

	public void setCuenta(CuentaBancaria cuenta) {
		this.cuenta = cuenta;
	}

	public Cliente(String numero, CuentaBancaria cuenta) {
		this.numero = numero;
		this.cuenta = cuenta;
	} 

	public void obtenerDatosDeCuenta() {
		System.out.printf("N�mero de la cuenta es: %s %nSaldo disponible: %f%n", this.cuenta.getNumero(),this.cuenta.getSaldo());
	}
	
	public static void main(String[] args) {
		CuentaBancaria cuenta = new CuentaBancaria("123456-7", 10500.75f);
		Cliente cliente = new Cliente("Juan Perez", cuenta);
		cliente.obtenerDatosDeCuenta();
	}
}
