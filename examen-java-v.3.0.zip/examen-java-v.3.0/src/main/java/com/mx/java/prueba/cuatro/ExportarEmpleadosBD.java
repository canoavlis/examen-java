package com.mx.java.prueba.cuatro;

import java.io.BufferedWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import org.h2.tools.DeleteDbFiles;

public class ExportarEmpleadosBD {

	public static void main(String... args) throws Exception {
		// delete the database named 'test' in the user home directory
		DeleteDbFiles.execute("~", "test", true);

		Class.forName("org.h2.Driver");
		Connection conn = DriverManager.getConnection("jdbc:h2:~/test");
		Statement stat = conn.createStatement();

		stat.execute("DROP TABLE IF EXISTS ESTADOS");
		stat.execute("CREATE TABLE ESTADOS(ID_ESTADO VARCHAR(2) PRIMARY KEY, NOMBRE VARCHAR(150))");
		stat.execute("INSERT INTO ESTADOS VALUES('01', 'Aguas Calientes')");
		stat.execute("INSERT INTO ESTADOS VALUES('02', 'Baja California')");
		stat.execute("INSERT INTO ESTADOS VALUES('03', 'Baja California Sur')");

		stat.execute("DROP TABLE IF EXISTS PLANTAS");
		stat.execute(
				"CREATE TABLE PLANTAS(ID_PLANTA VARCHAR(2) PRIMARY KEY, ID_ESTADO VARCHAR(2), NUMERO_EMPLEADOS INT, NOMBRE VARCHAR(150))");
		stat.execute("INSERT INTO PLANTAS VALUES('09','03',321,'LOS CABOS')");
		stat.execute("INSERT INTO PLANTAS VALUES('08','02',550,'MEXICALI')");
		stat.execute("INSERT INTO PLANTAS VALUES('01','02',1000,'TIJUANA')");

		StringBuffer datosEstados = new StringBuffer("ID_ESTADO,NUMERO_EMPLEADOS,NOMBRE").append("\n");
		ResultSet rs;
		rs = stat.executeQuery(
				"select NVL(sum(p.NUMERO_EMPLEADOS),0) AS TOTAL_EMPLEADOS,E.NOMBRE, e.ID_ESTADO from ESTADOS e LEFT join PLANTAS p ON e.ID_ESTADO = p.ID_ESTADO GROUP BY e.ID_ESTADO ORDER BY TOTAL_EMPLEADOS ASC");
		while (rs.next()) {
			datosEstados.append(String.format("%-10s", rs.getString("ID_ESTADO")))
					.append(String.format("%-17s", rs.getString("TOTAL_EMPLEADOS")))
					.append(String.format("%-20s", rs.getString("nombre"))).append("\n");
		}
		Path path = Paths.get("empleadosXestado.txt");
		BufferedWriter br = Files.newBufferedWriter(path, Charset.defaultCharset(), StandardOpenOption.CREATE);
		br.write(datosEstados.toString());
		br.newLine();
		System.out.println(datosEstados);
		stat.close();
		conn.close();
	}

}
